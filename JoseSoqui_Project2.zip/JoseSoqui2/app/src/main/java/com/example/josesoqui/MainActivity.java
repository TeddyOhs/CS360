package com.example.josesoqui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private Button buttonLogin;
    private Button buttonCreateLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI elements
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonCreateLogin = findViewById(R.id.buttonCreateLogin);

        // Set onClick listener for buttonLogin
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });

        // Set onClick listener for buttonCreateLogin
        buttonCreateLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createNewLogin();
            }
        });

        // Enable or disable buttonLogin based on editTextUsername and editTextPassword content
        enableLoginButton();

        // Add TextChangedListener for editTextUsername and editTextPassword to dynamically enable or disable buttonLogin
        editTextUsername.addTextChangedListener(textWatcher);
        editTextPassword.addTextChangedListener(textWatcher);
    }

    // (p3) Method to handle login functionality
    private void login() {
        // (p3) Implement login logic here
    }

    // (p3) Method to handle creating new login functionality
    private void createNewLogin() {
        // (p3) Implement logic for creating new login here
    }

    // Method to enable or disable buttonLogin based on editTextUsername and editTextPassword content
    private void enableLoginButton() {
        if (editTextUsername.getText().toString().trim().length() > 0 &&
                editTextPassword.getText().toString().trim().length() > 0) {
            buttonLogin.setEnabled(true);
        } else {
            buttonLogin.setEnabled(false);
        }
    }

    // TextWatcher to dynamically enable or disable buttonLogin based on editTextUsername and editTextPassword content
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            enableLoginButton();
        }

        @Override
        public void afterTextChanged(Editable s) {}
    };
}
