package com.example.josesoqui;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private GridView gridViewWeightData;
    private Button buttonAddWeight;
    private List<String> weightData;
    private ArrayAdapter<String> weightDataAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize UI elements
        gridViewWeightData = findViewById(R.id.gridViewWeightData);
        buttonAddWeight = findViewById(R.id.buttonAddWeight);

        // Initialize weight data list and adapter
        weightData = new ArrayList<>();
        weightDataAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, weightData);
        gridViewWeightData.setAdapter(weightDataAdapter);

        // Set click listener for "Add Weight" button
        buttonAddWeight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addWeightData();
            }
        });
    }

    // Method to add weight data
    private void addWeightData() {
        // For demonstration, add a dummy weight data entry
        String weightEntry = "Weight: 150 lbs";
        weightData.add(weightEntry);
        weightDataAdapter.notifyDataSetChanged(); // Notify adapter of data change
        Toast.makeText(this, "Weight added: " + weightEntry, Toast.LENGTH_SHORT).show();
    }
}
